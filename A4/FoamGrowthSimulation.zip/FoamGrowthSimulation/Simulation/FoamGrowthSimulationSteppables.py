
from PySteppables import *
import CompuCell
import sys
class FoamGrowthSimulationSteppable(SteppableBasePy):

    def __init__(self,_simulator,_frequency=100):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        self._output_file = open("output.dat","w")
    def start(self):
        # any code in the start function runs before MCS=0
        pass
    def step(self,mcs):        
        #type here the code that will run every _frequency MCS
        
        # temp values for min and max volume
        cells_sorted = sorted(self.cellList, key= lambda cell: cell.volume)
        min_volume = cells_sorted[0].volume
        max_volume = cells_sorted[-1].volume
        
        tier = (max_volume - min_volume)/3
               
        for cell in self.cellList:
            if (cell.volume < min_volume + (1*tier)):
                cell.type = self.FOAM_SMALL
            elif (cell.volume < min_volume + (2*tier)):
                cell.type = self.FOAM_MEDIUM
            else:
                cell.type = self.FOAM_LARGE
                
        self.writeCellDetails(mcs)

    def writeCellDetails(self,mcs):
        cells_sorted = sorted(self.cellList, key= lambda cell: cell.volume)
        min_volume = cells_sorted[0].volume
        max_volume = cells_sorted[-1].volume
                        
        self._output_file.write("Monte Carlo steps: ")
        self._output_file.write(str(mcs))
        self._output_file.write("\nNumber of cells: ")
        self._output_file.write(str(len(self.cellList)))
        self._output_file.write("\nId of smallest cell: ")
        self._output_file.write(str(cells_sorted[0].id))
        self._output_file.write("\nId of largest cell: ")
        self._output_file.write(str(cells_sorted[-1].id))
        self._output_file.write("\nVolume of smallest cell: ")
        self._output_file.write(str(min_volume))
        self._output_file.write("\nVolume of largest cell: ")
        self._output_file.write(str(max_volume))
        neighbor_ids = ""
        
        for neighbor , commonSurfaceArea in self.getCellNeighborDataList(cells_sorted[0]):
            if neighbor:
                neighbor_ids += str(neighbor.id) + " "
        self._output_file.write("\nNeighboring cell ids for smallest cell: ")
        self._output_file.write(neighbor_ids)
        
        for neighbor , commonSurfaceArea in self.getCellNeighborDataList(cells_sorted[-1]):
            if neighbor:
                neighbor_ids += str(neighbor.id) + " "
        self._output_file.write("\nNeighboring cell ids for largest cell: ")
        self._output_file.write(neighbor_ids + "\n\n")
        
        
    def finish(self):
        # Finish Function gets called after the last MCS
        self.writeCellDetails(self.potts.steps)
        close(self._output_file)
        